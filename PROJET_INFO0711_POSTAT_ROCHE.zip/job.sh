#!/bin/bash

#SBATCH --comment "CHPS0711"
#SBATCH -J "MD5_MPI"
#SBATCH --error=logs/job.%J.err
#SBATCH --output=logs/job.%J.out
#SBATCH -p short
#SBATCH --time=05:00:00
#SBATCH --mem 50000
#SBATCH -n 56
#SBATCH -N 2

# Definitions des parametres

omp=false
mpi=true
sequentiel=false
nThreads=56
mot="toute"
prefixe=2


module load intel/2018.3
module load openmpi/2.0.4.1.1_icc


if [ "$mpi" = true ]
then
    echo "Calcul temps MPI"
    echo "Temps MPI" > resMPI.txt
    echo "" >> resMPI.txt
    for (( i=29; i<=$nThreads; i++ ))
    do
        echo $i
        srun -n $i MPI/mainMPI $mot $prefixe | tail -n 1 >> resultats/resMPI.txt
    done
fi

if [ "$omp" = true ]
then
    echo "Calcul temps OMP"
    echo "Temps OMP" > resOMP.txt
    echo "" >> resOMP.txt
    for (( i=29; i<=$nThreads; i++ ))
    do
        echo $i
        export OMP_NUM_THREADS=$i
        ICC/mainICC $mot $prefixe o | tail -n 1 >> resultats/resOMP.txt
    done
fi

if [ "$sequentiel" = true ]
then
    echo "Calcul temps sequentiel"
    echo "Temps Sequentiel" > resSeq.txt
    echo "" >> resSeq.txt
    ICC/mainICC $mot $prefixe s | tail -n 1 >> resultats/resSeq.txt
fi